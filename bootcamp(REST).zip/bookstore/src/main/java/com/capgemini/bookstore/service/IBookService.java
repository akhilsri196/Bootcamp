package com.capgemini.bookstore.service;

import java.util.List;

import com.capgemini.bookstore.dto.Book;
import com.capgemini.bookstore.dto.Category;

public interface IBookService {

public Book findByBookId(int bookId);
	
	public List<Book> findByCategory(Category category);
}
