package com.capgemini.bookstore.service;

import com.capgemini.bookstore.dto.Category;

public interface ICategoryService {
	public Category findByCategoryName(String categoryName);
}
