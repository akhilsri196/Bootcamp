package com.capgemini.bookstore.service;

import com.capgemini.bookstore.dto.Admin;

public interface IAdminService {
	public Admin findByEmail(String email);
}
