package com.capgemini.bookstore.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.bookstore.dao.ICustomerDao;
import com.capgemini.bookstore.dto.Customer;

@Service
public class ICustomerServiceImpl implements ICustomerService {

	@Autowired
	ICustomerDao iCustomerDao;

@Override
	public Customer findByCustomerId(int customerId) {
		// TODO Auto-generated method stub
		return iCustomerDao.findById(customerId).get();
	}

	@Override
	public Customer findByEmailId(String emailId) {
		// TODO Auto-generated method stub
		return iCustomerDao.findByEmailId(emailId);
	}
}
