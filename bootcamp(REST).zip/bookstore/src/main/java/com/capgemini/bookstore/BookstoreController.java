package com.capgemini.bookstore;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.bookstore.dto.Category;
import com.capgemini.bookstore.service.IBookService;
import com.capgemini.bookstore.service.ICategoryService;

@RestController
public class BookstoreController {
    @Autowired
 	IBookService bookService;
    @Autowired
 	ICategoryService catService;
    
	@RequestMapping(method = RequestMethod.GET,value="all")
	public String sayHello() {
		Category cat=catService.findByCategoryName("Fiction");
		return bookService.findByCategory(cat).get(0).getAuthor();
		 
		
	}
	
}

