package com.capgemini.bookstore.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capgemini.bookstore.dto.Customer;
import com.capgemini.bookstore.dto.Order;

@Repository("iOrderDao")
public interface IOrderDao extends JpaRepository<Order,Integer>{
	
	//public Order findByOrderId(int orderId);
	
	public Order findByCustomer(Customer customer);

}
