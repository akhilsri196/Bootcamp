package com.capgemini.bookstore.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.bookstore.dao.IOrderDao;
import com.capgemini.bookstore.dto.Customer;
import com.capgemini.bookstore.dto.Order;

@Service
public class IOrderServiceImpl  implements IOrderService{

	@Autowired
	IOrderDao iOrderDao;

	@Override
	public Order findByOrderId(int orderId) {
		// TODO Auto-generated method stub
		return iOrderDao.findById(orderId).get();
	}

	@Override
	public Order findByCustomer(Customer customer) {
		// TODO Auto-generated method stub
		return iOrderDao.findByCustomer(customer);
	}
}
