package com.capgemini.bookstore.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capgemini.bookstore.dto.Admin;

@Repository("iAdminDao")
public interface IAdminDao extends JpaRepository<Admin,Integer>{
	
  public Admin findByEmail(String email);
}
