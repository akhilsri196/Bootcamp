package com.capgemini.bookstore.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capgemini.bookstore.dto.Book;
import com.capgemini.bookstore.dto.Customer;
import com.capgemini.bookstore.dto.Review;

@Repository("iReviewDao")
public interface IReviewDao extends JpaRepository<Review, Integer>{
	
	public Review findByBook(Book book);
	
	public Review findByCustomer(Customer customer);
	

}
