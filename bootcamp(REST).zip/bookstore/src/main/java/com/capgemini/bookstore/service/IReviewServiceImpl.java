package com.capgemini.bookstore.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.bookstore.dao.IReviewDao;
import com.capgemini.bookstore.dto.Book;
import com.capgemini.bookstore.dto.Customer;
import com.capgemini.bookstore.dto.Review;

@Service
public class IReviewServiceImpl implements IReviewService {

	@Autowired
	IReviewDao iReviewDao;

	@Override
	public Review findByBook(Book book) {
		// TODO Auto-generated method stub
		return iReviewDao.findByBook(book);
	}

	@Override
	public Review findByCustomer(Customer customer) {
		// TODO Auto-generated method stub
		return iReviewDao.findByCustomer(customer);
	}
}
