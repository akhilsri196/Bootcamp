package com.capgemini.bookstore.service;

import com.capgemini.bookstore.dto.Customer;

public interface ICustomerService {

	public Customer findByCustomerId(int customerId);
	
	public Customer findByEmailId(String emailId);
	
}
