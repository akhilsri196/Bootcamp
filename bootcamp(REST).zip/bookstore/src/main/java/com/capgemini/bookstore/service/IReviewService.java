package com.capgemini.bookstore.service;

import com.capgemini.bookstore.dto.Book;
import com.capgemini.bookstore.dto.Customer;
import com.capgemini.bookstore.dto.Review;

public interface IReviewService {

     public Review findByBook(Book book);
	
	public Review findByCustomer(Customer customer);
}
