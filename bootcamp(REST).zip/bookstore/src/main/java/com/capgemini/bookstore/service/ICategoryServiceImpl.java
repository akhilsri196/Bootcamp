package com.capgemini.bookstore.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.bookstore.dao.ICategoryDao;
import com.capgemini.bookstore.dto.Category;

@Service
public class ICategoryServiceImpl  implements ICategoryService{
	
	@Autowired
	ICategoryDao iCategoryDao;

	@Override
	public Category findByCategoryName(String categoryName) {
		// TODO Auto-generated method stub
		return iCategoryDao.findByCategoryName(categoryName);
	}
	
}
