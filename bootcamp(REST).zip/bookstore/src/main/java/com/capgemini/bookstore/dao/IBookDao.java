package com.capgemini.bookstore.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capgemini.bookstore.dto.Book;
import com.capgemini.bookstore.dto.Category;

@Repository("iBookDao")
public interface IBookDao extends JpaRepository<Book, Integer>{
	
	public Book findByBookId(int bookId);
	
	public List<Book> findByCategory(Category category);
}
