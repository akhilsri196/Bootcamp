package com.capgemini.bookstore.service;

import com.capgemini.bookstore.dto.Customer;
import com.capgemini.bookstore.dto.Order;

public interface IOrderService {
	public Order findByOrderId(int orderId);
	
	public Order findByCustomer(Customer customer);
}
