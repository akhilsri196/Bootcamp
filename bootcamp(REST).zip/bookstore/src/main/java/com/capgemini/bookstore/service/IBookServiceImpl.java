package com.capgemini.bookstore.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.bookstore.dao.IBookDao;
import com.capgemini.bookstore.dao.ICategoryDao;
import com.capgemini.bookstore.dto.Book;
import com.capgemini.bookstore.dto.Category;

@Service
public class  IBookServiceImpl implements IBookService{

	@Autowired
	IBookDao iBookDao;
	@Autowired
	ICategoryDao iCatDao;

	@Override
	public Book findByBookId(int bookId) {
		// TODO Auto-generated method stub
		return iBookDao.findByBookId(bookId);
	}

	@Override
	public List<Book> findByCategory(Category category) {
		// TODO Auto-generated method stub
		//iCatDao.findById(category.getCategoryId()).get();
		return iBookDao.findByCategory(category);
	}
	
}
