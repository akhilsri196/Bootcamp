package com.capgemini.bookstore.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capgemini.bookstore.dto.Book;
import com.capgemini.bookstore.dto.Category;

@Repository("iCategoryDao")
public interface ICategoryDao extends JpaRepository<Category, Integer> {

	
	public Category findByCategoryName(String categoryName);
	
	
}
