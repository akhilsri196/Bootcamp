package com.capgemini.bookstore.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.bookstore.beans.Admin;

public interface IBookstoreAdminDAO extends JpaRepository<Admin, Integer> {

}
