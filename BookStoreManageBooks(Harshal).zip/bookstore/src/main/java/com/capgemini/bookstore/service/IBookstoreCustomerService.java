package com.capgemini.bookstore.service;

public interface IBookstoreCustomerService {

}
