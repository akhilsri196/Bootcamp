package com.capgemini.bookstore.service;

import org.springframework.stereotype.Service;

import com.capgemini.bookstore.beans.BookDetails;

@Service
public interface IBookstoreAdminService {
	
	public void addBook(BookDetails book);
	 
	public void modifyBook(BookDetails book);
	
	public void deleteBook(int id);
	public Iterable<BookDetails> getAllBooks();
}
