package com.capgemini.bookstore.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.bookstore.beans.BookDetails;
import com.capgemini.bookstore.service.BookstoreAdminServiceimpl;



@RestController
@CrossOrigin("http://localhost:4200")
public class BookstoreAdminController {

	
	BookstoreAdminController bookstoreAdminController;
	
	

	@Autowired
	BookstoreAdminServiceimpl bookstoreAdminServiceImpl;
	
//	@PostMapping
//	public void addBook(@RequestBody()BookDetails book)
//	{
//		bookstoreAdminServiceImpl.addBook(book);
//	}	
	
	@PostMapping
	public void modifyBook(@RequestBody() BookDetails book)
	{
		bookstoreAdminServiceImpl.modifyBook(book);
	}
	
	@DeleteMapping(value="/{id}",produces="application/json")
	public void delEmployee(@PathVariable("id")int bookid)
	{
		bookstoreAdminServiceImpl.deleteBook(bookid);
	}
	
	@GetMapping(value="/all",produces="application/json")
	public Iterable<BookDetails> getAllBooks()
	{
		return bookstoreAdminServiceImpl.getAllBooks();
	}
}
