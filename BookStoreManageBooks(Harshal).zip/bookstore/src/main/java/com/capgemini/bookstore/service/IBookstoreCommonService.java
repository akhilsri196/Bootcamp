package com.capgemini.bookstore.service;

public interface IBookstoreCommonService {

}
