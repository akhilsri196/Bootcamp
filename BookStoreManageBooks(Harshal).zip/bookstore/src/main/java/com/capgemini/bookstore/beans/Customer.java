package com.capgemini.bookstore.beans;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.annotations.CreationTimestamp;

@Entity
@Table(name = "customer", uniqueConstraints = { @UniqueConstraint(columnNames = { "email", "mobileNumber" }) })
public class Customer {

	@Id
	@Column(name = "customerId")
	@NotNull
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int customerId;
	@Size(max = 30)
	@Size(min = 8)
	@Column(name = "fullname")
	@NotNull
	private String fullName;
	@Column(name = "email")
	@NotNull
	@Email
	@Size(min = 10)
	@Size(max = 64)
	private String email;
	@Column(name = "password")
	@Size(min = 8)
	@Size(max = 16)
	@NotNull
	private String password;
	@Column(name = "mobilenumber")
	@Size(min = 10)
	@Size(max = 15)
	@NotNull
	private String mobileNumber;
	@Column(name = "address")
	@Size(min = 10)
	@Size(max = 128)
	@NotNull
	private String address;
	@Column(name = "city")
	@Size(min = 3)
	@Size(max = 32)
	@NotNull
	private String city;
	@Column(name = "zipcode")
	@Size(min = 3)
	@Size(max = 24)
	@NotNull
	private int zipcode;
	@Column(name = "country")
	@Size(min = 3)
	@Size(max = 64)
	@NotNull
	private String counrty;
	@CreationTimestamp
	private LocalDate date;

	public Customer() {
		super();
	}



	public int getCustomerId() {
		return customerId;
	}



	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}



	public String getFullName() {
		return fullName;
	}



	public void setFullName(String fullName) {
		this.fullName = fullName;
	}



	public String getEmail() {
		return email;
	}



	public void setEmail(String email) {
		this.email = email;
	}



	public String getPassword() {
		return password;
	}



	public void setPassword(String password) {
		this.password = password;
	}



	public String getMobileNumber() {
		return mobileNumber;
	}



	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}



	public String getAddress() {
		return address;
	}



	public void setAddress(String address) {
		this.address = address;
	}



	public String getCity() {
		return city;
	}



	public void setCity(String city) {
		this.city = city;
	}



	public int getZipcode() {
		return zipcode;
	}



	public void setZipcode(int zipcode) {
		this.zipcode = zipcode;
	}



	public String getCounrty() {
		return counrty;
	}



	public void setCounrty(String counrty) {
		this.counrty = counrty;
	}



	public LocalDate getDate() {
		return date;
	}



	public void setDate(LocalDate date) {
		this.date = date;
	}



	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((address == null) ? 0 : address.hashCode());
		result = prime * result + ((city == null) ? 0 : city.hashCode());
		result = prime * result + ((counrty == null) ? 0 : counrty.hashCode());
		result = prime * result + customerId;
		result = prime * result + ((date == null) ? 0 : date.hashCode());
		result = prime * result + ((email == null) ? 0 : email.hashCode());
		result = prime * result + ((fullName == null) ? 0 : fullName.hashCode());
		result = prime * result + ((mobileNumber == null) ? 0 : mobileNumber.hashCode());
		result = prime * result + ((password == null) ? 0 : password.hashCode());
		result = prime * result + zipcode;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Customer other = (Customer) obj;
		if (address == null) {
			if (other.address != null)
				return false;
		} else if (!address.equals(other.address))
			return false;
		if (city == null) {
			if (other.city != null)
				return false;
		} else if (!city.equals(other.city))
			return false;
		if (counrty == null) {
			if (other.counrty != null)
				return false;
		} else if (!counrty.equals(other.counrty))
			return false;
		if (customerId != other.customerId)
			return false;
		if (date == null) {
			if (other.date != null)
				return false;
		} else if (!date.equals(other.date))
			return false;
		if (email == null) {
			if (other.email != null)
				return false;
		} else if (!email.equals(other.email))
			return false;
		if (fullName == null) {
			if (other.fullName != null)
				return false;
		} else if (!fullName.equals(other.fullName))
			return false;
		if (mobileNumber == null) {
			if (other.mobileNumber != null)
				return false;
		} else if (!mobileNumber.equals(other.mobileNumber))
			return false;
		if (password == null) {
			if (other.password != null)
				return false;
		} else if (!password.equals(other.password))
			return false;
		if (zipcode != other.zipcode)
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", fullName=" + fullName + ", email=" + email + ", password="
				+ password + ", mobileNumber=" + mobileNumber + ", address=" + address + ", city=" + city + ", zipcode="
				+ zipcode + ", counrty=" + counrty + ", date=" + date + "]";
	}




}