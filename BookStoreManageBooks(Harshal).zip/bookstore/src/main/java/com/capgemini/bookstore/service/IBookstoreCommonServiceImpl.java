package com.capgemini.bookstore.service;

public class IBookstoreCommonServiceImpl implements IBookstoreCommonService {

}
