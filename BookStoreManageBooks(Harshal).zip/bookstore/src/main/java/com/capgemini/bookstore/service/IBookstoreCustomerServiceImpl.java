package com.capgemini.bookstore.service;

public class IBookstoreCustomerServiceImpl implements IBookstoreCustomerService {

}
