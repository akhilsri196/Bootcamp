package com.capgemini.bookstore.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.bookstore.beans.BookDetails;
import com.capgemini.bookstore.dao.IBookstoreAdminDAO;
import com.capgemini.bookstore.dao.IBookstoreBookDAO;


@Service
public class BookstoreAdminServiceimpl implements IBookstoreAdminService{

	@Autowired
	IBookstoreBookDAO bookstorebookDao;
	
	@Transactional
	@Override
	public void addBook(BookDetails book) {
		bookstorebookDao.save(book);
	}
	
	@Transactional
	@Override
	public void modifyBook(BookDetails book) {
		
		bookstorebookDao.save(book);
	}

	@Transactional
	@Override
	public void deleteBook(int id) {
		bookstorebookDao.deleteById(id);
	}

	public Iterable<BookDetails> getAllBooks() {
		return bookstorebookDao.findAll();
	}

}
