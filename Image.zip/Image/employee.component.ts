import { Component ,OnInit } from '@angular/core';
import { Employee } from './employee';
import { empData } from './employee.data';
import { EmployeeService } from './employee.service';
@Component({
   selector:'emp-data',
   templateUrl:'./employee.component.html', 
   styles:[]
})
export class EmployeeComponent implements OnInit
{
   emp:Employee[];
   e:Employee=new Employee(0,null,0);
   selectedFile:File;
   url:string; 
   public constructor(private employeeService:EmployeeService){}
   ngOnInit()   {   }
   public getEmployees():void
   { 
      this.employeeService.getEmployees().subscribe(data=>{this.emp=data});
   }
   public getEmployee():void
   {
      this.employeeService.getEmployee(this.e.empid).subscribe(data=>{this.e=data});
   }
   public addEmployee():void
   {
      this.employeeService.addEmployee(this.e).subscribe();
   }
   public modEmployee():void
   {
       this.employeeService.modEmployee(this.e).subscribe();
   }
   public delEmployee():void
   {
       this.employeeService.delEmployee(this.e.empid).subscribe();
   }
   onFileSelected(event)
    {
       if (event.target.files && event.target.files[0]) 
       {
         var reader = new FileReader();

         reader.onload = (event: any) => {
          this.url = event.target.result;
         }

         reader.readAsDataURL(event.target.files[0]);
        }
    }
}








