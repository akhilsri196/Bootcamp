import { Employee } from "./employee";
import { empData } from "./employee.data";
import { Injectable } from '@angular/core';

@Injectable({
    providedIn: 'root',
  })
export class EmployeeService
{
public getEmployees():Employee[]
{
    return empData;
}

}