import { Employee } from './employee';

export const empData:Employee[]=[new Employee(9,"Rohit Sharma",4000000),
new Employee(10,"Shikhar Dhawan",100),
new Employee(11,"MS Dhoni",5000000),
new Employee(12,"Virat Kohli",200),
new Employee(1,"Jaspreet Bumrah",4000000),
new Employee(2,"KL Rahul",100),
new Employee(114,"B Kumar",5000000),
new Employee(123,"Kedar Jadhav",200)];