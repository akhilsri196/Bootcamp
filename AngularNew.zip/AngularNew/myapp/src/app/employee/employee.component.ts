import { Component, OnInit } from '@angular/core';
import { Employee } from '../employee';
import { empData } from '../employee.data';
import { EmployeeService } from "../employee.service";
@Component({

  selector: 'app-employee',

  templateUrl:'./employee.component.html',
  styleUrls: ['./employee.component.css']

})

export class EmployeeComponent implements OnInit 
{

  //emp={'empid':2323,'ename':'Akhilesh Srivastava','salary':22000};
 // emp:Employee=new Employee(999,"Rohit Sharma",2000000);
 /*emp:Employee[]=[new Employee(9,"Rohit Sharma",4000000),
 new Employee(10,"Shikhar Dhawan",100),
 new Employee(11,"MS Dhoni",5000000),
 new Employee(12,"Virat Kohli",200)];*/
 
 //emp:Employee[]=empData;
 emp:Employee[];
 public constructor(private employeeService:EmployeeService) { 
 }

   ngOnInit() {
    this.emp=this.employeeService.getEmployees();
  }


}
