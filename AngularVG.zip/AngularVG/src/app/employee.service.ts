import { Employee } from './employee';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
@Injectable()
export class EmployeeService
{
   public constructor(private httpClient:HttpClient){}
   public getEmployees():Observable<Employee[]>
   {
        return this.httpClient.get<Employee[]>('http://localhost:8089/all'); 
   }
   public getEmployee(empid):Observable<Employee>
   {
        return this.httpClient.get<Employee>('http://localhost:8089/'+empid); 
   }
   public addEmployee(emp):any
   {
     return this.httpClient.post('http://localhost:8089',emp);
   } 
   public modEmployee(emp):any
   {
     return this.httpClient.put('http://localhost:8089',emp);
   } 
   public delEmployee(empid):any
   {
      return this.httpClient.delete('http://localhost:8089/'+empid);
   }
}








