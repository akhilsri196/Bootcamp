import { Employee } from './employee';
export const empData:Employee[]=[
                   new Employee(999,'Rohith Sharma',50000),
                   new Employee(786,'Sachin Tendulkar',60000),
                   new Employee(123,'Virat Kohli',55000),
                   new Employee(321,'Bumrah',45000), 
                   new Employee(555,'Yuvraj Singh',75000)
                  ];