export class Employee
{
   empid:number;
   ename:string;
   salary:number;
   public constructor(empid:number,ename:string,salary:number)
   {
       this.empid=empid;  this.ename=ename; this.salary=salary;
   }
} 