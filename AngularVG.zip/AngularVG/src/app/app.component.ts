

import { Component } from '@angular/core';


@Component({
  
   selector: 'myTag',
  
   templateUrl: './app.component.html',
  
   styles: ['h1{text-align:center;color:magenta}']

})

export class AppComponent 
{
 
    //name:string='Sachin';
    name='Sachin';
}
