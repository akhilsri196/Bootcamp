package com.example.demo.service;
import org.springframework.stereotype.Service;
import com.example.demo.entity.Employee;
@Service
public interface EmployeeService 
{
   public Employee getEmployee(int empid);
   public Iterable<Employee> getEmployees();
   public void addEmployee(Employee emp);
   public void modifyEmployee(Employee emp);
   public void deleteEmployee(int empid);
}
