import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css'],
 
})
export class EmployeeComponent implements OnInit {

  constructor() { }
  ngOnInit() {
this.hello();
  }
eId:number=50;
eName:String="Akhilesh";
eDesignation:String="Analyst A4";
imagepath:String="assets/images/download (1).jpg";
imagepath2:String="assets/images/download.jpg";
clickMessage:String="";
checkVariable:number=1;
today: number = Date.now();
anyday:any=new Date(1997, 5, 19);
empList:any=[{id:101,eName:"Vaibhav",job:"Analyst22"},
{id:102,eName:"Pandey",job:"Analyst04"},
{id:103,eName:"Harshal",job:"Analyst26"},];

hello()
{
  alert("Hi.. Welcome to Angular Tutorial");
}
onClickMe()
{
  
this.clickMessage="Hi "+this.eName+" this is button msg";
alert(this.clickMessage);
}
}
