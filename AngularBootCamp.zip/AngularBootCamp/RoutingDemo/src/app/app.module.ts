import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { RouterModule } from '@angular/router';
import { HomeComponent } from "./home/home.component"; 
import { LoginComponent } from "./login/login.component";
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { CustomerComponent } from './customer/customer.component';
import { CustomerService } from './customer/customer.service';
import { UserComponent } from './user/user.component';
import { HttpClient,HttpClientModule } from "@angular/common/http";
import { UserService } from './user/user.service';
@NgModule({
  declarations: [
    AppComponent,HomeComponent,LoginComponent, HeaderComponent, FooterComponent, CustomerComponent, UserComponent
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot(
[
{path:'home',component:HomeComponent},
{path:'login',component:LoginComponent},


]
    ),
    AppRoutingModule,
    HttpClientModule
  ],
  providers: [CustomerService,UserService],
  bootstrap: [AppComponent,UserComponent]
})
export class AppModule { }
