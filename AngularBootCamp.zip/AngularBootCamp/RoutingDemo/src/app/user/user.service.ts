import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/internal/Observable';


@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private http:HttpClient) { }
url:string="http://localhost:8095/getCarDTOlist";
getUser():Observable<any>
{
 return this.http.get(this.url);
}

}
