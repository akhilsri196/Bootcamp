import { Component, OnInit } from '@angular/core';
import { UserService } from './user.service';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css'],
  providers:[UserService]
})
export class UserComponent implements OnInit {

  constructor(private service:UserService) { }
  cars={'make':2323,'model':'Akhilesh Srivastava','modelYear':22000};
  private carlist:any;  
  ngOnInit() {
    this.getUser();
  }
  getUser()
  {
   this.service.getUser().subscribe(data =>{this.carlist=data} ,error => console.log(error));
  }

}
