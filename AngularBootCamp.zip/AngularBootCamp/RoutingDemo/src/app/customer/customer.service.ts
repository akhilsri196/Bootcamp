import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {

  constructor() { }

  getCustomer()
  {
    return new Customer(101,"Akhilesh");
  }
}

export class Customer {
  cid:number;
  cname:String;
  constructor(cid,cname) {
    this.cid=cid;
    this.cname=cname;
   }
  
}

