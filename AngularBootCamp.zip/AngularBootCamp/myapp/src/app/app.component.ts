import { Component } from '@angular/core';


@Component({
 
  selector: 'app-root',
  
  templateUrl: './app.component.html',

  styles: ['h1{text-align:center;color:blue}']

})
export class AppComponent {
  

name= 'Akhilesh';

count:number=0;
public clicked():void
{
this.count++;
}
}

