import { Component, OnInit, Input,Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-b',
  template: '<h2>child displays</h2>{{childData}} <br> <button (click)="sendMessageToParent()">click</button>',
  styleUrls: ['./b.component.css']
})
export class BComponent implements OnInit {

  @Input() childData:string;
  @Output() cEvent=new EventEmitter();
  public sendMessageToParent()
  {
    this.cEvent.emit("Hello Parent");
  }
  constructor() { }

  ngOnInit() {
  }

}
