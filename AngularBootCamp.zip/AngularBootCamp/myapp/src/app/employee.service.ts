import { Employee } from "./employee";
//import { empData } from "./employee.data";
import { Injectable } from '@angular/core';

import { Observable } from "rxjs";

import { HttpClient } from '@angular/common/http';
@Injectable({
    providedIn: 'root',
  })
export class EmployeeService
{
//public getEmployees():Employee[]
//{
  //  return empData;
//}
url:string="http://localhost:8095/getCarDTOlist";
urladd="http://localhost:8095/CarDTO";
urledit="http://localhost:8095/updateCarDTO";
urlfindone="http://localhost:8095/CarDTO";
urlDelete="http://localhost:8095/deleteCarDTO";
constructor(private httpClient:HttpClient) { }
public getCars():Observable<any>
{
  return this.httpClient.get(this.url);
}

public addCar(car: any):any
{
   return this.httpClient.post(this.urladd,car);
}

public findOneCar(carid: any):Observable<any>
{
   return this.httpClient.get(this.urlfindone+"/"+carid);
}
public deleteCar(carid: any):any
{
  return this.httpClient.delete(this.urlDelete+"/"+carid);
}
public editCar(car: any):any
{
   return this.httpClient.put(this.urledit,car);
}


}