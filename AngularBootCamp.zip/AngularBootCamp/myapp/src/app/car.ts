export class car
{
id:number;
make:string;
model:string;
modelYear:string;
public constructor(make:string,model:string,modelYear:string) {
this.make=make;
this.model=model;
this.modelYear=modelYear;
}
}