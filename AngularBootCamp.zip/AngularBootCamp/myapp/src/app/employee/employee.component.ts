import { Component, OnInit } from '@angular/core';
import { Employee } from '../employee';
import { empData } from '../employee.data';
import { EmployeeService } from "../employee.service";
import { car } from '../car';

@Component({

  selector: 'app-employee',

  templateUrl:'./employee.component.html',
  styleUrls: ['./employee.component.css']

})

export class EmployeeComponent implements OnInit 
{

  //emp={'empid':2323,'ename':'Akhilesh Srivastava','salary':22000};
 // emp:Employee=new Employee(999,"Rohit Sharma",2000000);
 /*emp:Employee[]=[new Employee(9,"Rohit Sharma",4000000),
 new Employee(10,"Shikhar Dhawan",100),
 new Employee(11,"MS Dhoni",5000000),
 new Employee(12,"Virat Kohli",200)];*/
 
 //emp:Employee[]=empData;
 cars:any;
 car:car=new car("","","");
 editid:number;
 findThisId:any;
 deleteThisId:any;
 public constructor(private employeeService:EmployeeService) { 
 }

   ngOnInit() {
   //  this.showAllCars();
   this.employeeService.getCars().subscribe(data =>{this.cars=data});
}
public addCar():void
{
    this.employeeService.addCar(this.car).subscribe();
    this.showAllCars();
}
public editCar(findThisId:any):void
{
   this.findThisId=findThisId;
    this.findOneCar();
   
   // this.showAllCars();
}
public finalEdit()
{
  this.employeeService.editCar(this.car).subscribe();
  this.showAllCars();
}
public findOneCar():any
{
  this.employeeService.findOneCar(this.findThisId).subscribe(data =>{this.car=data});
}
public deleteCar(car:car):void
{

  this.deleteThisId=car.id;
  this.employeeService.deleteCar(this.deleteThisId).subscribe(data => {this.cars = this.cars.filter(c => c !== car);});
  //this.showAllCars();
}
public blank()
{
  this.car=new car("","","");
}
public showAllCars():void
{
  this.employeeService.getCars().subscribe(data =>{this.cars=data});
}
}
