package com.example.demo.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.dao.EmployeeDAO;
import com.example.demo.entity.Employee;
@Service
public class EmployeeServiceImpl implements EmployeeService
{
   @Autowired
   EmployeeDAO employeeDAO;
   public void setEmployeeDAO(EmployeeDAO employeeDAO) 
   {
	  this.employeeDAO = employeeDAO;
   }
   public Employee getEmployee(int empid)
   {
	   return employeeDAO.findById(empid).get();
   }
   public Iterable<Employee> getEmployees()
   {
	   return employeeDAO.findAll();
   }
   @Transactional
   public void addEmployee(Employee emp)
   {
	   employeeDAO.save(emp);
   }
   @Transactional
   public void modifyEmployee(Employee emp)
   {
	   employeeDAO.save(emp);
   }
   @Transactional
   public void deleteEmployee(int empid)
   {
	   employeeDAO.deleteById(empid);
   }
}
